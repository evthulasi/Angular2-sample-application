﻿export {HomeComponent} from './movie/home.component';
export {MoviesComponent} from './movie/movies.component';
export {MovieDetailComponent} from './movie/movie-detail.component';
export {MovieService} from './movie/movie.service';
export {MovieResult} from './movie/movie-result.component';