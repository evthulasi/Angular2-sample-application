﻿export class IMovies {
    title: string;
    Year: number;
    rated: string;
    released: string;
    genre: string;
    director: string;
    plot: string;
    language: string;
    country: string;
    awards: string;
    poster: string;
    imdbRating: number;
    imdbID: string;
}