System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var IMovies;
    return {
        setters:[],
        execute: function() {
            IMovies = (function () {
                function IMovies() {
                }
                return IMovies;
            }());
            exports_1("IMovies", IMovies);
        }
    }
});
//# sourceMappingURL=movies.js.map