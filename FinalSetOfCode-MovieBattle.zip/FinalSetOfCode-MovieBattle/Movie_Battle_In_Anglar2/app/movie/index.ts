﻿export {MovieDetailComponent} from './movie-detail.component';
export {MovieResult} from './movie-result.component';
export {MoviesInfoComponent} from './movies-info.component';
export {IMovies} from './movies';
export {MovieService} from './movie.service';
